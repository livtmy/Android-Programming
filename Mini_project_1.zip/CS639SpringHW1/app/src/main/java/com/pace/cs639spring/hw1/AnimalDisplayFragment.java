package com.pace.cs639spring.hw1;

import android.app.Fragment;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Mengyuan and kachi on 2/20/2019.
 */

public class AnimalDisplayFragment extends Fragment {

    ImageView birdImage;
    ImageView catImage;
    ImageView dogImage;
    ImageView currentImage;
    TextView birdDescription;
    TextView catDescription;
    TextView dogDescription;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.animal_display, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        birdImage = getView().findViewById(R.id.bird_image);
        catImage = getView().findViewById(R.id.cat_image);
        dogImage = getView().findViewById(R.id.dog_image);

        birdDescription = getView().findViewById(R.id.bird_description);
        catDescription = getView().findViewById(R.id.cat_description);
        dogDescription = getView().findViewById(R.id.dog_description);

        birdImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                birdDescription.setVisibility(View.VISIBLE);
                catDescription.setVisibility(View.INVISIBLE);
                dogDescription.setVisibility(View.INVISIBLE);
            }
        });

        catImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                birdDescription.setVisibility(View.INVISIBLE);
                catDescription.setVisibility(View.VISIBLE);
                dogDescription.setVisibility(View.INVISIBLE);
            }
        });

        dogImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                birdDescription.setVisibility(View.INVISIBLE);
                catDescription.setVisibility(View.INVISIBLE);
                dogDescription.setVisibility(View.VISIBLE);
            }
        });
    }

    protected void rotateImage() {
        currentImage = getCurrentImage();
        if (currentImage == null) {
            Toast.makeText(getActivity(),
                    R.string.please_select_an_animal_image_before_choosing_an_image_modification,
                    Toast.LENGTH_LONG).show();
        } else {
            currentImage.setRotation((currentImage.getRotation() + 90) % 360);
        }
    }

    // Flip the image around the y-axis
    protected void flipImage() {
        currentImage = getCurrentImage();
        if (currentImage == null) {
            Toast.makeText(getActivity(),
                    R.string.please_select_an_animal_image_before_choosing_an_image_modification,
                    Toast.LENGTH_LONG).show();
        } else {
            if (currentImage.getRotation() % 180 == 0) {
                // For cases of the initial state and after an even number of rotations
                currentImage.setScaleX(currentImage.getScaleX() == 1 ? -1 : 1);
            } else {
                // For cases of after an odd number of rotation
                currentImage.setScaleY(currentImage.getScaleY() == 1 ? -1 : 1);
            }
        }
    }


    protected void moveImageUpward() {
        currentImage = getCurrentImage();
        if (currentImage == null) {
            Toast.makeText(getActivity(),
                    R.string.please_select_an_animal_image_before_choosing_an_image_modification,
                    Toast.LENGTH_LONG).show();
        } else {
            currentImage.setTranslationY(currentImage.getTranslationY() - dpToPx(10));
        }
    }

    protected void moveImageForward() {
        currentImage = getCurrentImage();
        if (currentImage == null) {
            Toast.makeText(getActivity(),
                    R.string.please_select_an_animal_image_before_choosing_an_image_modification,
                    Toast.LENGTH_LONG).show();
        } else {
            currentImage.setTranslationX(currentImage.getTranslationX() + dpToPx(10));
        }
    }

    public void resetImage() {
        currentImage = getCurrentImage();
        if (currentImage == null) {
            Toast.makeText(getActivity(),
                    R.string.please_select_an_animal_image_before_choosing_an_image_modification,
                    Toast.LENGTH_LONG).show();
        } else {
            currentImage.setTranslationX(0);
            currentImage.setTranslationY(0);
        }
    }

    protected void moveImageBackward() {
        currentImage = getCurrentImage();
        if (currentImage == null) {
            Toast.makeText(getActivity(),
                    R.string.please_select_an_animal_image_before_choosing_an_image_modification, Toast.LENGTH_LONG).show();
        } else {
            currentImage.setTranslationX(currentImage.getTranslationX() - dpToPx(10));
        }
    }

    protected void moveImageDownward() {
        currentImage = getCurrentImage();
        if (currentImage == null) {
            Toast.makeText(getActivity(),
                    R.string.please_select_an_animal_image_before_choosing_an_image_modification, Toast.LENGTH_LONG).show();
        } else {
            currentImage.setTranslationY(currentImage.getTranslationY() + dpToPx(10));
        }
    }

    // Find which animal image is selected by checking the visibilities of animal descriptions
    // If no animal image is selected, return null
    private ImageView getCurrentImage() {
        if (birdDescription.getVisibility() == View.VISIBLE) {
            return birdImage;
        } else if (catDescription.getVisibility() == View.VISIBLE) {
            return catImage;
        } else if (dogDescription.getVisibility() == View.VISIBLE) {
            return dogImage;
        } else {
            return null;
        }
    }

    // Transfer dp to pixels
    private float dpToPx(int dpValue) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dpValue, getResources().getDisplayMetrics());
    }
}
