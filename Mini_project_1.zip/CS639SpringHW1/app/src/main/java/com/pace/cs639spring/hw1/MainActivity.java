package com.pace.cs639spring.hw1;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Button rotateButton;
    Button flipButton;
    ImageView upwardImage;
    ImageView forwardImage;
    ImageView resetImage;
    ImageView backwardImage;
    ImageView downwardImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        AnimalDisplayFragment animalDisplayFragment = new AnimalDisplayFragment();
        fragmentTransaction.add(R.id.animal_display_fragment_container, animalDisplayFragment);
        fragmentTransaction.commit();

        rotateButton = findViewById(R.id.rotate_button);
        flipButton = findViewById(R.id.flip_button);
        upwardImage = findViewById(R.id.upward_button);
        forwardImage = findViewById(R.id.forward_button);
        resetImage = findViewById(R.id.reset_button);
        backwardImage = findViewById(R.id.backward_button);
        downwardImage = findViewById(R.id.downward_button);

        rotateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animalDisplayFragment.rotateImage();
            }
        });

        flipButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animalDisplayFragment.flipImage();
            }
        });

        upwardImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animalDisplayFragment.moveImageUpward();
            }
        });

        forwardImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animalDisplayFragment.moveImageForward();
            }
        });

        resetImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animalDisplayFragment.resetImage();
            }
        });

        backwardImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animalDisplayFragment.moveImageBackward();
            }
        });

        downwardImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animalDisplayFragment.moveImageDownward();
            }
        });
    }
}
